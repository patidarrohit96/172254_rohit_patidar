export class CouponData{
    CouponCode:String;
}